# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render, redirect
from django.http import HttpResponse, HttpResponseRedirect
from example.models import student
from django.core.exceptions import ObjectDoesNotExist
from example.forms import StudentForm, StudentSearchForm, StudentEditForm
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator

def display(request):
    return HttpResponse('<H2>Started Second Project</H2>')


def index(request):
    database = student.objects.all()
    database_paginated = Paginator(list(database), 4)

    list_of_lists = []

    for i in range(database_paginated.num_pages):
        page = database_paginated.page(i+1)
        list_of_lists.append(list(page.object_list))

    context={'database':database,'projectname':'StudentDataBase', 'list_of_lists': list_of_lists}
    return render(request,'index.html',context)


def get_user(request, roll_no):
    try:
        std = student.objects.get(rollnumber=roll_no)
    except ObjectDoesNotExist:
        return HttpResponse("<h4>404 ERROR</h4>")
    context={'student':std}
    return render(request, 'get_user.html', context)


def create_user(request):
    if request.method == "POST":
        #what to do when request is a post request
        form = StudentForm(request.POST)
        if form.is_valid():

            name    = form.cleaned_data['name']
            age     = form.cleaned_data['age']
            sex     = form.cleaned_data['sex']
            roll_no = form.cleaned_data['rollnumber']

            student.objects.create(name=name, age=age,sex=sex, rollnumber=roll_no)
            return HttpResponse("User created successfully")
    else:
        #what to do when request is a get request
        form = StudentForm()
        context = {'form':form}
        return render(request, 'create_user.html', context)

    #student.objects.create(name=name, age=age, sex=sex, roll_no=roll_no)

def display_user(request):
    if request.method == "POST":
        form = StudentSearchForm(request.POST)
        if form.is_valid():
            roll_no = form.cleaned_data['rollnumber']
            std = student.objects.get(rollnumber=roll_no)
            context = {'student': std}
            return render(request, 'get_user.html', context )

    else:
        form = StudentSearchForm()
        context = {'form': form}
        return render(request, 'display_user.html', context)

def edit_user(request, roll_no):
    std = student.objects.get(rollnumber=roll_no)

    if request.method=="POST":
        form = StudentEditForm(request.POST, instance=std)
        print form
        if form.is_valid():
            form.save()
            return redirect('index')
        else:
            return HttpResponse("<h4>FAILED</h4")
    else:
        #std = student.objects.get(rollnumber=roll_no)
        form = StudentEditForm(instance=std)
        return render(request, 'edit_user.html', {'form': form})


# Create your views here.
