# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin
from example.models import student, Subject

admin.site.register(student)
admin.site.register(Subject)

# Register your models here.
