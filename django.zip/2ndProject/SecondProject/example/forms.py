from django.forms import ModelForm
from example.models import student
from django import forms

class StudentForm(ModelForm):
    class Meta:
        model = student
        fields = '__all__'

class StudentEditForm(ModelForm):
    class Meta:
        model = student
        fields = ['name', 'sex','age']


class StudentSearchForm(forms.Form):
    rollnumber = forms.IntegerField()
