from django.conf.urls import url
from .  import views

urlpatterns=[
        url(r'^display/$',views.display,name="display"),
        url(r'^index/$',views.index,name="index"),
        url(r'get_user/(?P<roll_no>\d+)/$', views.get_user, name="get_student"),
        url(r'^create_user/$', views.create_user,name="create_user"),
        url(r'^display_user/$', views.display_user, name="display_user"),
        url(r'^edit_user/(?P<roll_no>\d+)/$', views.edit_user, name="edit_user")
        ]
