# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from django.http import HttpResponse
from studentDB.models import Student
from django import forms
from studentDB.forms import studentForm


def display(request):
    return HttpResponse("<H2>ThirdProject studentDB")


def create_user(request):
    
    if request.method=='POST':
        form = studentForm(request.POST)
        if form.is_valid():
            name=form.cleaned_data['Name']
            age=form.cleaned_data['Age']
            gender=form.cleaned_data['Gender']
            std_id=form.cleaned_data['Id']

            Student.objects.create(Name=name,Age=age,Gender=gender,Id=std_id)
            return HttpResponse("<H1>Successfully created " +name)
        return HttpResponse("<H3>In POST method form is not valid</H3>")
    elif request.method=='GET':
        form=studentForm()
        context={'form':form}
        return render(request,"create_user.html",context)

def get_user(request):
    if request.method=='POST':
        form = studentSearchForm(request.POST)
        if form.is_valid():
            std_id = form.cleaned_data['Id']
            student = Student.objects.get(Id=std_id)
            context = {'student':std,'name':student.Name}
            return render(request,"get_user.html",context)
    elif request.method == 'GET':
        form = studentSearchForm()
        context={'form':form}
        return render(request,"user.html",context)


# Create your views here.


