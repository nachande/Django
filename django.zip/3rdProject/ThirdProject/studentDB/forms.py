from django.forms import ModelForm
from studentDB.models import Student
from django import forms


class studentForm(ModelForm):
    class Meta:
        model = Student
        fields = '__all__'

class studentSearchForm(forms.Form):
    Id = forms.IntegerField()
