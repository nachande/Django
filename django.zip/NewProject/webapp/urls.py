from django.conf.urls import url
from . import views 

urlpatterns=[
        url(r'^hello/$',views.display, name='display'),
        url(r'^bhanu/$',views.NewFun, name='NewFun'),
        url(r'^demo/$',views.demo,name='demo')]
