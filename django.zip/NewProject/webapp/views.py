from django.shortcuts import render
from django.http import HttpResponse
from . models import employees,user

def display(request):
    return HttpResponse("<H2>Wonderfull Bhanu you Did it</H2>")

def NewFun(request):
    return HttpResponse("<H1>Another Function Called</H1>")

def demo(request):
    empData=employees.objects.all()
    context={'empData':empData,'key':123}
    return render(request,'index.html',context)



# Create your views here.
