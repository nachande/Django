from django.contrib import admin
from . models import employees,user

admin.site.register(employees)
admin.site.register(user)
# Register your models here.


